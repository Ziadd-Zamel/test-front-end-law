var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/attorney/category/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__0bb31eb0._.js")
R.c("server/chunks/node_modules_aabd9bee._.js")
R.c("server/chunks/node_modules_next_50b79fdf._.js")
R.m(76897)
R.m(6805)
module.exports=R.m(6805).exports
