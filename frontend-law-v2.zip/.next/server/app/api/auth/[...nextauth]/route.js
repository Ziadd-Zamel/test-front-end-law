var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/[...nextauth]/route.js")
R.c("server/chunks/[root-of-the-server]__fa414ad4._.js")
R.c("server/chunks/node_modules_72b83ed0._.js")
R.c("server/chunks/[root-of-the-server]__1ac1ecac._.js")
R.m(43433)
R.m(3413)
module.exports=R.m(3413).exports
