globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": [
      "static/chunks/e60ef129113f6e24.js",
      "static/chunks/5f36254eaa9140ff.js",
      "static/chunks/turbopack-01d1d4fcae91afed.js"
    ],
    "/_error": [
      "static/chunks/17722e3ac4e00587.js",
      "static/chunks/5f36254eaa9140ff.js",
      "static/chunks/turbopack-756c17872b07ad55.js"
    ]
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/146f90d7c1a7ab0a.js",
    "static/chunks/a7fa77a8a283aee4.js",
    "static/chunks/ab12c98d27106880.js",
    "static/chunks/8082ab48faca5ea1.js",
    "static/chunks/522518d740397639.js",
    "static/chunks/c19da6693934fea1.js",
    "static/chunks/turbopack-f52c2acacde14fa4.js"
  ],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];