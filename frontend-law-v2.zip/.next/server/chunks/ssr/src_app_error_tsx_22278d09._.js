module.exports=[23953,a=>{"use strict";a.s(["default",()=>c]);var b=a.i(87924);function c(){return(0,b.jsx)("div",{children:"error"})}}];

//# sourceMappingURL=src_app_error_tsx_22278d09._.js.map