module.exports=[3363,a=>{"use strict";a.s(["default",()=>c]);var b=a.i(7997);function c(){return(0,b.jsx)("div",{children:"page-is-not-found"})}}];

//# sourceMappingURL=src_app_not-found_tsx_3f23d179._.js.map