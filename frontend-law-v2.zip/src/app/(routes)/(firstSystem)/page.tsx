export default function page() {
  return (
    <>
      <p className="text-5xl flex items-center justify-center w-full h-full">
        adsssssssss
      </p>
    </>
  );
}
