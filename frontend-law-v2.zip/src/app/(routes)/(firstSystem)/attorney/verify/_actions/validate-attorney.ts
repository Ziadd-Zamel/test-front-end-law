"use server";

import { AttorneyValidationFields } from "@/lib/schemas/attorney.schema";
import { getAuthHeader } from "@/lib/utils/auth-header";

export async function validateAttorney(data: AttorneyValidationFields) {
  try {
    const token = await getAuthHeader();
    const response = await fetch(
      `${process.env.API}/Attorney/validate-attorney`,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token.token}`,
        },
        body: JSON.stringify(data),
      }
    );

    console.log(response);
    const result = await response.json();

    if (!response.ok) {
      return {
        error: result.message || `HTTP error! status: ${response.status}`,
      };
    }

    return { success: true, data: result };
  } catch (error) {
    return {
      error: error instanceof Error ? error.message : "حدث خطأ غير متوقع",
    };
  }
}
