import ValidateAttorneyForm from "./_components/validate-attorney-form";

export default function Page() {
  return <ValidateAttorneyForm />;
}
