"use client";

import { useMutation } from "@tanstack/react-query";
import { toast } from "sonner";
import { validateAttorney } from "../_actions/validate-attorney";
import { AttorneyValidationFields } from "@/lib/schemas/attorney.schema";

export default function useAttorneyValidation() {
  const { isPending, error, mutate, data } = useMutation({
    mutationFn: async (data: AttorneyValidationFields) => {
      const result = await validateAttorney(data);

      if (result.error) {
        throw new Error(result.error);
      }

      return result.data;
    },
    onSuccess: () => {
      toast.success("تم التحقق من المحامي بنجاح!");
    },
    onError: (error) => {
      toast.error(error?.message || "حدث خطأ أثناء التحقق من المحامي");
    },
  });

  return {
    isPending,
    error,
    validateAttorney: mutate,
    validationData: data,
  };
}
