"use server";

import { getAuthHeader } from "@/lib/utils/auth-header";
import { revalidatePath } from "next/cache";

export async function addAttorney(formData: FormData) {
  try {
    const token = await getAuthHeader();

    const response = await fetch(`${process.env.API}/Attorney/add-attorney`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${token.token}`,
      },
      body: formData,
    });
    console.log(token.token);
    const result = await response.json();
    console.log(result);

    if (!response.ok) {
      return {
        error: result.message || `HTTP error! status: ${response.status}`,
      };
    }

    revalidatePath("/attorney/list");
    return { success: true, data: result };
  } catch (error) {
    return {
      error: error instanceof Error ? error.message : "حدث خطأ غير متوقع",
    };
  }
}
