"use client";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Form } from "@/components/ui/form";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import useAddAttorney from "../_hooks/use-add-attorney";
import {
  AddAttorneyFields,
  AddAttorneySchema,
} from "@/lib/schemas/attorney.schema";
import PdfUploader from "@/components/common/pdf-uploader";

type Company = {
  id: number;
  name: string;
};

type Client = {
  id: number;
  fullName: string;
};

export default function AddAttorneyForm({
  companies,
  clients,
}: {
  companies: Company[];
  clients: Client[];
}) {
  const { addAttorney, isPending } = useAddAttorney();

  const form = useForm<AddAttorneyFields>({
    resolver: zodResolver(AddAttorneySchema),
    defaultValues: {
      attorneyNumber: "",
      clientType: undefined,
      clientId: undefined,
    },
  });

  // Watch the clientType to determine which data to show
  const clientType = form.watch("clientType");

  // Reset clientId when clientType changes
  const handleClientTypeChange = (value: "client" | "company") => {
    form.setValue("clientType", value);
    form.resetField("clientId");
  };

  // Get the appropriate data based on client type
  const getClientData = () => {
    if (clientType === "client") {
      return clients;
    } else if (clientType === "company") {
      return companies;
    }
    return [];
  };

  async function onSubmit(values: AddAttorneyFields) {
    const formData = new FormData();
    formData.append("AttorneyNumber", values.attorneyNumber);
    formData.append("ClientType", values.clientType);
    formData.append("ClientId", values.clientId.toString());
    formData.append("AttorneyPdf", values.attorneyPdf, values.attorneyPdf.name);

    console.log("FormData being sent:");
    for (const [key, value] of formData.entries()) {
      console.log(`${key}:`, value);
    }

    addAttorney(formData, {
      onSuccess: () => {
        form.reset();
      },
    });
  }

  return (
    <Form {...form}>
      <form
        onSubmit={form.handleSubmit(onSubmit)}
        className="space-y-6 w-full p-8 bg-white rounded-2xl shadow-md"
      >
        {/* Attorney Number */}
        <FormField
          control={form.control}
          name="attorneyNumber"
          render={({ field }) => (
            <FormItem>
              <FormLabel>رقم الوكالة</FormLabel>
              <FormControl>
                <Input {...field} placeholder="أدخل رقم الوكالة" />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <div className="flex items-center md:flex-row flex-col justify-between gap-5">
          {/* CLIENT TYPE */}
          <FormField
            control={form.control}
            name="clientType"
            render={({ field }) => (
              <FormItem className="md:w-1/2 w-full">
                <FormLabel>نوع العميل</FormLabel>
                <Select
                  onValueChange={handleClientTypeChange}
                  value={field.value}
                >
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue placeholder="اختر نوع العميل" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    <SelectItem value="company">شخصية اعتبارية</SelectItem>
                    <SelectItem value="client">شخصية طبيعية</SelectItem>
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />

          {/* CLIENT SELECT */}
          <FormField
            control={form.control}
            name="clientId"
            render={({ field }) => (
              <FormItem className="md:w-1/2 w-full">
                <FormLabel>اختر العميل</FormLabel>
                <Select
                  onValueChange={(value) =>
                    field.onChange(value ? parseInt(value) : undefined)
                  }
                  value={field.value?.toString() || ""}
                  disabled={!clientType}
                >
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue placeholder="اختر العميل" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    {getClientData().map((item) => (
                      <SelectItem key={item.id} value={String(item.id)}>
                        {clientType === "client"
                          ? (item as Client).fullName
                          : (item as Company).name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        {/* ATTORNEY PDF */}
        <FormField
          control={form.control}
          name="attorneyPdf"
          render={({ field: { value, onChange } }) => (
            <FormItem>
              <FormLabel className="text-base font-semibold">
                ملف الوكالة (PDF)
              </FormLabel>
              <FormControl>
                <PdfUploader
                  value={value}
                  onChange={(file) => {
                    console.log("PDF onChange called with:", file);
                    onChange(file);
                  }}
                  maxSizeMB={5}
                  disabled={isPending}
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        {/* SUBMIT BUTTON */}
        <div className="space-y-3">
          <Button type="submit" className="w-full h-12" disabled={isPending}>
            {isPending ? "جار الإضافة..." : "إضافة الوكالة"}
          </Button>
        </div>
      </form>
    </Form>
  );
}
