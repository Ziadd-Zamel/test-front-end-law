"use client";

import { useMutation } from "@tanstack/react-query";
import { toast } from "sonner";
import { addAttorney } from "../_actions/add-attorney";

export default function useAddAttorney() {
  const { isPending, error, mutate } = useMutation({
    mutationFn: async (formData: FormData) => {
      const result = await addAttorney(formData);

      if (result.error) {
        throw new Error(result.error);
      }

      return result.data;
    },
    onSuccess: () => {
      toast.success("تم إضافة الوكالة بنجاح!");
    },
    onError: (error) => {
      toast.error(error?.message || "حدث خطأ أثناء إضافة الوكالة");
    },
  });

  return {
    isPending,
    error,
    addAttorney: mutate,
  };
}
