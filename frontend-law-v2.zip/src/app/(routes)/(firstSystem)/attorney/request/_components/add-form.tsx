"use client";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Form } from "@/components/ui/form";
import { Button } from "@/components/ui/button";
import {
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Checkbox } from "@/components/ui/checkbox";
import { Textarea } from "@/components/ui/textarea";
import MultipleSelector, { Option } from "@/components/ui/multiple-selector";
import useAttorneyRequest from "../_hooks/use-add-attorney";
import {
  AttorneyRequestFields,
  AttorneyRequestSchema,
} from "@/lib/schemas/attorney.schema";
import { useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { getAttorneyCategoryById } from "@/lib/api/attorney.api.client";

type AttorneyCategory = {
  id: number;
  externalId: string;
  name: string;
  typeName: string;
  parentId: number | null;
  parentName: string | null;
  children: AttorneyCategory[];
  createdAt: string;
  updatedAt: string;
};

type Company = {
  id: number;
  name: string;
};

type Client = {
  id: number;
  fullName: string;
};

export default function AddForm({
  data,
  companies,
  clients,
}: {
  data: AttorneyCategory[];
  companies: Company[];
  clients: Client[];
}) {
  const { createAttorneyRequest, isPending } = useAttorneyRequest();
  const [selectedCategories, setSelectedCategories] = useState<number[]>([]);
  const [selectedSubcategories, setSelectedSubcategories] = useState<number[]>(
    []
  );

  const form = useForm<AttorneyRequestFields>({
    resolver: zodResolver(AttorneyRequestSchema),
    defaultValues: {
      clientType: undefined,
      clientId: undefined,
      attorneyCapacity: undefined,
      attorneyType: "",
      attorneyDuration: undefined,
      additionalNotes: "",
    },
  });

  // Fetch subcategories for selected categories
  const { data: categoriesWithChildren, isLoading: isCategoriesLoading } =
    useQuery({
      queryKey: ["selected-categories", selectedCategories],
      queryFn: async () => {
        if (selectedCategories.length === 0) return [];

        const results = await Promise.all(
          selectedCategories.map(async (categoryId) => {
            try {
              const response = await getAttorneyCategoryById(categoryId);
              const mainCategory = data.find((c) => c.id === categoryId);
              return {
                mainCategory,
                details: response.data,
              };
            } catch (error) {
              console.error(`Failed to fetch category ${categoryId}:`, error);
              return null;
            }
          })
        );

        return results.filter(
          (
            r
          ): r is {
            mainCategory: AttorneyCategory;
            details: AttorneyCategory;
          } => r !== null && r.mainCategory !== undefined
        );
      },
      enabled: selectedCategories.length > 0,
    });

  // Main category options
  const attorneyTypeOptions: Option[] = useMemo(() => {
    if (!data || !Array.isArray(data) || data.length === 0) {
      return [];
    }

    const options = data
      .filter((category) => category && category.id && category.typeName)
      .map((category) => ({
        label: category.typeName,
        value: category.id.toString(),
      }));

    return options;
  }, [data]);

  const clientType = form.watch("clientType");

  const handleClientTypeChange = (value: "client" | "company") => {
    form.setValue("clientType", value);
    form.resetField("clientId");
  };

  const getClientData = () => {
    if (clientType === "client") {
      return clients;
    } else if (clientType === "company") {
      return companies;
    }
    return [];
  };

  // Update the form field with combined main and sub categories as comma-separated string
  const updateAttorneyTypeField = (mainCats: number[], subCats: number[]) => {
    const combined = [...mainCats, ...subCats];
    form.setValue("attorneyType", combined.join(","));
  };

  const handleCategoryChange = (selected: Option[]) => {
    const values = selected.map((opt) => Number(opt.value));
    setSelectedCategories(values);
    // Keep existing subcategories but update the form
    updateAttorneyTypeField(values, selectedSubcategories);
  };

  const handleSubcategoryToggle = (subcategoryId: number) => {
    setSelectedSubcategories((prev) => {
      const newSelection = prev.includes(subcategoryId)
        ? prev.filter((id) => id !== subcategoryId)
        : [...prev, subcategoryId];

      // Update form field with combined main and sub
      updateAttorneyTypeField(selectedCategories, newSelection);

      return newSelection;
    });
  };

  const handleSelectAll = (categoryChildren: AttorneyCategory[]) => {
    const childIds = categoryChildren.map((child) => child.id);

    setSelectedSubcategories((prev) => {
      // Check if all children are already selected
      const allSelected = childIds.every((id) => prev.includes(id));

      let newSelection;
      if (allSelected) {
        // Deselect all children of this category
        newSelection = prev.filter((id) => !childIds.includes(id));
      } else {
        // Select all children of this category
        const uniqueIds = new Set([...prev, ...childIds]);
        newSelection = Array.from(uniqueIds);
      }

      // Update form field with combined main and sub
      updateAttorneyTypeField(selectedCategories, newSelection);

      return newSelection;
    });
  };

  const isAllSelected = (categoryChildren: AttorneyCategory[]) => {
    if (categoryChildren.length === 0) return false;
    return categoryChildren.every((child) =>
      selectedSubcategories.includes(child.id)
    );
  };

  async function onSubmit(values: AttorneyRequestFields) {
    // Convert the comma-separated string to array of numbers before sending
    const payload = {
      ...values,
      attorneyType: values.attorneyType.split(",").map(Number),
    };
    createAttorneyRequest(payload, {
      onSuccess: () => {
        // Reset form
        form.reset();
        // Reset states
        setSelectedCategories([]);
        setSelectedSubcategories([]);
      },
    });
  }

  return (
    <Form {...form}>
      <form
        onSubmit={form.handleSubmit(onSubmit)}
        className="space-y-6 w-full p-8 bg-white rounded-2xl shadow-md"
      >
        <div className="flex items-center md:flex-row flex-col justify-between gap-5">
          {/* CLIENT TYPE */}
          <FormField
            control={form.control}
            name="clientType"
            render={({ field }) => (
              <FormItem className="md:w-1/2 w-full">
                <FormLabel>نوع العميل</FormLabel>
                <Select
                  onValueChange={handleClientTypeChange}
                  value={field.value}
                >
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue placeholder="اختر نوع العميل" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    <SelectItem value="client">شخصية اعتبارية</SelectItem>
                    <SelectItem value="company">شخصية طبيعية</SelectItem>
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />

          {/* CLIENT SELECT */}
          <FormField
            control={form.control}
            name="clientId"
            render={({ field }) => (
              <FormItem className="md:w-1/2 w-full">
                <FormLabel>اختر العميل</FormLabel>
                <Select
                  onValueChange={(value) =>
                    field.onChange(value ? parseInt(value) : undefined)
                  }
                  value={field.value?.toString() || ""}
                  disabled={!clientType}
                >
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue placeholder="اختر العميل" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    {getClientData().map((item) => (
                      <SelectItem key={item.id} value={String(item.id)}>
                        {clientType === "client"
                          ? (item as Client).fullName
                          : (item as Company).name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <div className="flex items-center md:flex-row flex-col justify-between gap-5">
          {/* ATTORNEY CAPACITY */}
          <FormField
            control={form.control}
            name="attorneyCapacity"
            render={({ field }) => (
              <FormItem className="md:w-1/2 w-full">
                <FormLabel>صفة المحامي</FormLabel>
                <Select onValueChange={field.onChange} value={field.value}>
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue placeholder="اختر صفة المحامي" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    <SelectItem value="اصالة عن نفسه">اصالة عن نفسه</SelectItem>
                    <SelectItem value="محامي">محامي</SelectItem>
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />

          {/* ATTORNEY DURATION */}
          <FormField
            control={form.control}
            name="attorneyDuration"
            render={({ field }) => (
              <FormItem className="md:w-1/2 w-full">
                <FormLabel>مدة الوكالة</FormLabel>
                <Select onValueChange={field.onChange} value={field.value}>
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue placeholder="اختر مدة الوكالة" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    <SelectItem value="3_months">3 أشهر</SelectItem>
                    <SelectItem value="6_months">6 أشهر</SelectItem>
                    <SelectItem value="9_months">9 أشهر</SelectItem>
                    <SelectItem value="1_year">سنة واحدة</SelectItem>
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        {/* MAIN ATTORNEY CATEGORIES */}
        <FormField
          control={form.control}
          name="attorneyType"
          render={() => (
            <FormItem>
              <FormLabel>نوع الوكالة الرئيسي</FormLabel>
              <MultipleSelector
                defaultOptions={attorneyTypeOptions}
                placeholder="اختر أنواع الوكالة الرئيسية..."
                emptyIndicator={
                  <p className="text-center text-lg leading-10 text-gray-600">
                    لا توجد نتائج
                  </p>
                }
                value={selectedCategories
                  .map((v) =>
                    attorneyTypeOptions.find(
                      (opt) => opt.value === v.toString()
                    )
                  )
                  .filter((opt): opt is Option => opt !== undefined)}
                onChange={handleCategoryChange}
              />
              <FormMessage />
            </FormItem>
          )}
        />

        {/* ACCORDIONS FOR SELECTED CATEGORIES (OPTIONAL) */}
        {selectedCategories.length > 0 && (
          <div>
            <FormLabel>الوكالات الفرعية (اختياري)</FormLabel>
            {isCategoriesLoading ? (
              <div className="border rounded-lg p-4 text-center text-gray-500 mt-2">
                جاري تحميل الفئات...
              </div>
            ) : categoriesWithChildren &&
              categoriesWithChildren.filter(
                (item) =>
                  item.details &&
                  item.details.children &&
                  item.details.children.length > 0
              ).length > 0 ? (
              <div className="border rounded-lg mt-2">
                <Accordion type="multiple" className="w-full">
                  {categoriesWithChildren
                    ?.filter(
                      (item) =>
                        item.details &&
                        item.details.children &&
                        item.details.children.length > 0
                    )
                    .map((item) => {
                      const { mainCategory, details } = item;

                      return (
                        <AccordionItem
                          key={mainCategory.id}
                          value={`item-${mainCategory.id}`}
                        >
                          <AccordionTrigger className="px-4 hover:no-underline">
                            <div className="flex items-center justify-between w-full">
                              <span className="font-medium">
                                {mainCategory.typeName}
                              </span>
                              <span className="text-sm text-gray-500 mr-2 mt-1">
                                (
                                {
                                  details.children.filter((child) =>
                                    selectedSubcategories.includes(child.id)
                                  ).length
                                }
                                /{details.children.length})
                              </span>
                            </div>
                          </AccordionTrigger>
                          <AccordionContent className="px-4 pb-4">
                            {/* Select All Option */}
                            <div className="flex items-center space-x-2 space-x-reverse pb-3 mb-3 border-b">
                              <Checkbox
                                id={`select-all-${mainCategory.id}`}
                                checked={isAllSelected(details.children)}
                                onCheckedChange={() =>
                                  handleSelectAll(details.children)
                                }
                              />
                              <label
                                htmlFor={`select-all-${mainCategory.id}`}
                                className="text-sm font-bold leading-none cursor-pointer mr-2"
                              >
                                تحديد الكل
                              </label>
                            </div>

                            {/* Individual Checkboxes */}
                            <div className="space-y-3">
                              {details.children.map((child) => (
                                <div
                                  key={child.id}
                                  className="flex items-center space-x-2 space-x-reverse"
                                >
                                  <Checkbox
                                    id={`subcategory-${child.id}`}
                                    checked={selectedSubcategories.includes(
                                      child.id
                                    )}
                                    onCheckedChange={() =>
                                      handleSubcategoryToggle(child.id)
                                    }
                                  />
                                  <label
                                    htmlFor={`subcategory-${child.id}`}
                                    className="text-sm mr-2 font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 cursor-pointer"
                                  >
                                    {child.name}
                                  </label>
                                </div>
                              ))}
                            </div>
                          </AccordionContent>
                        </AccordionItem>
                      );
                    })}
                </Accordion>
              </div>
            ) : (
              <div className="border rounded-lg p-4 text-center text-gray-500 mt-2">
                لا توجد وكالات فرعية للفئات المحددة
              </div>
            )}
            {selectedSubcategories.length > 0 && (
              <p className="text-sm text-gray-600 mt-2">
                تم اختيار {selectedSubcategories.length} وكالة فرعية
              </p>
            )}
          </div>
        )}

        {/* ADDITIONAL NOTES */}
        <FormField
          control={form.control}
          name="additionalNotes"
          render={({ field }) => (
            <FormItem>
              <FormLabel>ملاحظات إضافية</FormLabel>
              <FormControl>
                <Textarea
                  {...field}
                  placeholder="ملاحظات..."
                  className="min-h-28"
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        {/* SUBMIT BUTTON */}
        <Button
          type="submit"
          className="w-full h-12 mt-10"
          disabled={isPending}
        >
          {isPending ? "جار الإنشاء..." : "إنشاء طلب الوكالة"}
        </Button>
      </form>
    </Form>
  );
}
