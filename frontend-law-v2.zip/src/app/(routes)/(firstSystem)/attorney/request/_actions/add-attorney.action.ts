"use server";

import { getAuthHeader } from "@/lib/utils/auth-header";
import { revalidatePath } from "next/cache";
interface AttorneyRequestPayload {
  clientType: "client" | "company";
  clientId: number;
  attorneyCapacity: "اصالة عن نفسه" | "محامي";
  attorneyType: number[];
  attorneyDuration: "3_months" | "6_months" | "9_months" | "1_year";
  additionalNotes?: string;
}
export async function createAttorneyRequest(data: AttorneyRequestPayload) {
  try {
    const token = await getAuthHeader();
    const response = await fetch(
      `${process.env.API}/Attorney/request-new-attorney`,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token.token}`,
        },
        body: JSON.stringify(data),
      }
    );

    const result = await response.json();
    if (!response.ok) {
      return {
        error: result.message || `HTTP error! status: ${response.status}`,
      };
    }
    revalidatePath("attorney/list");
    return { success: true, data: result };
  } catch (error) {
    return {
      error: error instanceof Error ? error.message : "حدث خطأ غير متوقع",
    };
  }
}
