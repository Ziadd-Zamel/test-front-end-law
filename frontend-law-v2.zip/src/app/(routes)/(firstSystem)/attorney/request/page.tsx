import AddAttorney from "./_components/add-attorney";

export default function Page() {
  return <AddAttorney />;
}
