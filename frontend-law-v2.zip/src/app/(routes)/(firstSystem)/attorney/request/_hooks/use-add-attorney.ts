"use client";
import { useMutation } from "@tanstack/react-query";
import { toast } from "sonner";
import { createAttorneyRequest } from "../_actions/add-attorney.action";

interface AttorneyRequestPayload {
  clientType: "client" | "company";
  clientId: number;
  attorneyCapacity: "اصالة عن نفسه" | "محامي";
  attorneyType: number[];
  attorneyDuration: "3_months" | "6_months" | "9_months" | "1_year";
  additionalNotes?: string;
}

export default function useAttorneyRequest() {
  const { isPending, error, mutate } = useMutation({
    mutationFn: async (data: AttorneyRequestPayload) => {
      const result = await createAttorneyRequest(data);

      if (result.error) {
        throw new Error(result.error);
      }

      return result.data;
    },
    onSuccess: () => {
      toast.success("تم إنشاء طلب الوكالة بنجاح!");
    },
    onError: (error: Error) => {
      toast.error(error?.message || "حدث خطأ أثناء إنشاء طلب الوكالة");
    },
  });

  return {
    isPending,
    error,
    createAttorneyRequest: mutate,
  };
}
