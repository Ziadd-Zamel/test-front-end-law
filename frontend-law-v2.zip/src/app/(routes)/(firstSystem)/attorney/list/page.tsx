import catchError from "@/lib/utils/catch-error";
import { getAllAttorney } from "@/lib/api/attorney.api";
import AttorneyTable from "./_components/attorney-table";
import {
  TableEmptyState,
  TableErrorState,
} from "@/components/common/table-states";

export default async function Page() {
  const [payload, error] = await catchError(() => getAllAttorney());

  // Handle error state
  if (error) {
    return (
      <div className="box-container p-5 md:p-20">
        <div className="rounded-xl bg-white border border-gray-300 min-h-[400px]">
          <TableErrorState
            title="Failed to load attorney data"
            description="We couldn't retrieve the attorney information. Please check your connection and try again."
            error={error}
          />
        </div>
      </div>
    );
  }

  // Handle empty state
  if (!payload?.data || payload.data.length === 0) {
    return (
      <div className="box-container p-5 md:p-20">
        <div className="rounded-xl bg-white border border-gray-300 min-h-[400px]">
          <TableEmptyState
            title="لا توجد وكالات قانونية"
            description="لم يتم العثور على أي وكالات قانونية. أضف أول وكالة للبدء."
            actionLabel="إضافة وكالة جديدة"
          />
        </div>
      </div>
    );
  }
  return (
    <div className=" w-full box-container pt-20">
      <div className="!w-full">
        <AttorneyTable attorney={payload.data} />
      </div>
    </div>
  );
}
