"use client";

import * as React from "react";
import { TableBuilder } from "@/components/common/table-builder";
import { TableCell, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";

import { Attorney } from "@/lib/types/attorney";
import { cn } from "@/lib/utils";
import NameFilter from "./name-filter";
import StatuFilter from "./status-filter";
import Link from "next/link";
import { Button } from "@/components/ui/button";

const requestStatusStyles = {
  sent_to_client: "bg-blue-100 text-blue-800 hover:bg-blue-200",
  pending: "bg-yellow-100 text-yellow-800 hover:bg-yellow-200",
  approved: "bg-green-100 text-green-800 hover:bg-green-200",
  rejected: "bg-red-100 text-red-800 hover:bg-red-200",
  in_progress: "bg-orange-100 text-orange-800 hover:bg-orange-200",
};

const statusLabels: Record<string, string> = {
  sent_to_client: "تم الإرسال للعميل",
  pending: "في الانتظار",
  approved: "موافق عليه",
  rejected: "مرفوض",
  in_progress: "قيد التنفيذ",
};

const requestHeader = [
  { headName: "رقم الطلب", className: "text-center" },
  { headName: "اسم العميل", className: "text-center" },
  { headName: "نوع الوكالة", className: "text-center" },
  { headName: "تاريخ الإنشاء", className: "text-center" },
  { headName: "الحالة", className: "text-center" },
  { headName: "الإجرائات", className: "text-center" },
];

export default function AttorneyTable({ attorney }: { attorney: Attorney[] }) {
  const [selectedName, setSelectedName] = React.useState("");
  const [selectedStatus, setSelectedStatus] = React.useState("");
  return (
    <TableBuilder<Attorney>
      hasFooter={false}
      tableHeader={
        <>
          <div className="flex items-center justify-between w-full md:gap-0 gap-6  md:flex-row flex-col">
            <div className="flex self-start items-center gap-2">
              <div className="w-1 h-5 bg-gradient-to-b from-blue-400 to-white" />
              <h2 className="text-3xl font-semibold">ادارة الوكالات</h2>
            </div>

            <div className="flex items-center gap-4 self-end sm:flex-row flex-col">
              <NameFilter value={selectedName} onChange={setSelectedName} />
              <StatuFilter
                value={selectedStatus}
                onChange={setSelectedStatus}
              />
            </div>
          </div>
        </>
      }
      tableHeadNames={requestHeader}
      tableData={attorney}
      headRowClasses="text-center"
      renderRow={(request) => (
        <TableRow key={request.id}>
          <TableCell className="text-center">#{request.id}</TableCell>
          <TableCell className="text-center">
            <p className="font-medium">{request.clientName}</p>
          </TableCell>
          <TableCell className="text-center">
            <p className="text-sm font-medium">
              {request.attorneyMainType || "غير محدد"}
            </p>
          </TableCell>
          <TableCell className="text-center">
            <p>{request.createdAtFormatted}</p>
            <p className="text-sm font-normal text-gray-500">
              {request.createdDay} {request.createdMonth} {request.createdYear}
            </p>
          </TableCell>
          <TableCell className="text-center">
            <div className="flex justify-center">
              <Badge
                variant="secondary"
                className={cn(requestStatusStyles[request.status])}
              >
                {statusLabels[request.status]}
              </Badge>
            </div>
          </TableCell>
          <TableCell className="text-center">
            <Link href={`/attorney/list/${request.id}`}>
              <Button variant={"ghost"}>التفاصيل</Button>
            </Link>
          </TableCell>
        </TableRow>
      )}
    />
  );
}
