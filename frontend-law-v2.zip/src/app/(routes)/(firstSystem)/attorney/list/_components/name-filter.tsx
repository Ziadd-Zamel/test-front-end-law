"use client";
import * as React from "react";
import { CheckIcon, ChevronsUpDownIcon } from "lucide-react";
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
} from "@/components/ui/command";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

const fakeNames = [
  "أحمد علي",
  "سارة محمد",
  "خالد إبراهيم",
  "منى حسن",
  "يوسف سمير",
];

export default function NameFilter({
  value,
  onChange,
  placeholder = "ابحث عن اسم العميل...",
}: {
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
}) {
  const [open, setOpen] = React.useState(false);

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button
          variant={"trigger"}
          role="combobox"
          aria-expanded={open}
          className=" w-full sm:w-[200px] lg:w-[300px] justify-between"
        >
          {value || placeholder}
          <ChevronsUpDownIcon className="ml-2 h-4 w-4 shrink-0 opacity-50" />
        </Button>
      </PopoverTrigger>

      <PopoverContent className="w-full sm:w-[200px] lg:w-[300px]  p-0">
        <Command>
          <CommandInput placeholder={placeholder} />
          <CommandList>
            <CommandEmpty>لا يوجد نتيجة.</CommandEmpty>
            <CommandGroup>
              {fakeNames.map((name) => (
                <CommandItem
                  key={name}
                  value={name}
                  onSelect={(currentValue) => {
                    // Toggle behaviour: select same value to clear
                    const newVal = currentValue === value ? "" : currentValue;
                    onChange(newVal);
                    setOpen(false);
                  }}
                >
                  <CheckIcon
                    className={cn(
                      "mr-2 h-4 w-4",
                      value === name ? "opacity-100" : "opacity-0"
                    )}
                  />
                  {name}
                </CommandItem>
              ))}
            </CommandGroup>
          </CommandList>
        </Command>
      </PopoverContent>
    </Popover>
  );
}
