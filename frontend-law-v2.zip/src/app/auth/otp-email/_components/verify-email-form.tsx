"use client";
import OTPForm from "../../_components/otp-form";
import useVerifyEmail from "../hooks/use-verify-email";

export default function VerifyEmailForm() {
  const { verify, isPending: isVerifyPending } = useVerifyEmail();

  return <OTPForm onVerify={verify} isVerifyPending={isVerifyPending} />;
}
