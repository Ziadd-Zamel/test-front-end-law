"use client";
import { useMutation } from "@tanstack/react-query";
import { useRouter } from "next/navigation";
import { toast } from "sonner";
import { verifyEmailCode } from "../actions/verify-email.action";

export default function useVerifyEmail() {
  const router = useRouter();

  const { isPending, error, mutate } = useMutation({
    mutationFn: async (code: string) => {
      const result = await verifyEmailCode(code);

      if (result.error) {
        throw new Error(result.error);
      }

      return result.data;
    },
    onSuccess: () => {
      toast.success("تم التحقق من البريد الإلكتروني بنجاح ");
      router.push("/auth/otp-whatsapp");
    },
    onError: (error) => {
      console.error("Verify email error:", error);
      toast.error(error?.message || "حدث خطأ أثناء التحقق من الرمز");
    },
  });

  return { isPending, error, verify: mutate };
}
