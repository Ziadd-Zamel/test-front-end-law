import { signIn } from "next-auth/react";
import { useMutation } from "@tanstack/react-query";
import { LoginFields } from "@/lib/schemas/auth.schema";
import { toast } from "sonner";
import { useRouter } from "next/navigation";

export default function useLogin() {
  const router = useRouter();
  // Mutation for login with NextAuth
  const { isPending, error, mutate } = useMutation({
    mutationFn: async ({ identity, password }: LoginFields) => {
      const response = await signIn("credentials", {
        identity,
        password,
        redirect: false,
      });

      if (response?.error) {
        throw new Error(response.error);
      }

      return response;
    },
    onSuccess: (data) => {
      toast.success("مرحباً بك! تم تسجيل دخولك بنجاح.");
      router.push("/");
      console.log(data);
    },
    onError: (error) => {
      console.error("Login error:", error);
      toast.error(error?.message || "حدث خطأ أثناء تسجيل الدخول");
    },
  });

  return {
    isPending,
    error,
    login: mutate,
  };
}
