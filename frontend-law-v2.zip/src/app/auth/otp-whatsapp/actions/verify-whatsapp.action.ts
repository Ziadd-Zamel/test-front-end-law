"use server";

import { cookies } from "next/headers";

export async function verifyWhatsappCode(code: string) {
  try {
    const cookieStore = await cookies();
    const token = cookieStore.get("registerToken")?.value;

    if (!token) {
      return { error: "Token not found in cookies" };
    }

    const response = await fetch(`${process.env.API}/Verify/Code`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify({
        code: code,
        typeOfGenerate: "RegisterUserWhats",
      }),
    });

    const result = await response.json();

    if (!response.ok) {
      return {
        error: result.message || `HTTP error! status: ${response.status}`,
      };
    }

    return { success: true, data: result };
  } catch (error) {
    return {
      error:
        error instanceof Error
          ? error.message
          : "An unexpected error occurred while verifying WhatsApp code",
    };
  }
}
