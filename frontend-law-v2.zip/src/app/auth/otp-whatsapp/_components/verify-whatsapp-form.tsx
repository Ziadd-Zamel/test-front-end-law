"use client";

import OTPForm from "../../_components/otp-form";
import useVerifyWhatsapp from "../hooks/use-verify-whatsapp";

export default function VerifywhatsappForm() {
  const { verify, isPending: isVerifyPending } = useVerifyWhatsapp();

  return <OTPForm onVerify={verify} isVerifyPending={isVerifyPending} />;
}
