"use client";

import { useMutation } from "@tanstack/react-query";
import { useRouter } from "next/navigation";
import { toast } from "sonner";
import { verifyWhatsappCode } from "../actions/verify-whatsapp.action";

export default function useVerifyWhatsapp() {
  const router = useRouter();

  const { isPending, error, mutate } = useMutation({
    mutationFn: async (code: string) => {
      const result = await verifyWhatsappCode(code);

      if (result.error) {
        throw new Error(result.error);
      }

      return result.data;
    },
    onSuccess: () => {
      toast.success("تم التحقق من رقم واتساب بنجاح ");
      router.push("/dashboard");
    },
    onError: (error) => {
      console.error("Verify WhatsApp error:", error);
      toast.error(error?.message || "حدث خطأ أثناء التحقق من رمز واتساب ");
    },
  });

  return { isPending, error, verify: mutate };
}
