"use server";
import { RegisterFields } from "@/lib/schemas/auth.schema";

export async function registerUser(data: RegisterFields) {
  try {
    const response = await fetch(`${process.env.API}/Register`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(data),
    });

    const result = await response.json();

    if (!response.ok) {
      return {
        error: result.message || `HTTP error! status: ${response.status}`,
      };
    }

    return { success: true, data: result };
  } catch (error) {
    return {
      error:
        error instanceof Error
          ? error.message
          : "An unexpected error occurred while registering user",
    };
  }
}
