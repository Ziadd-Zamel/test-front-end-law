// Hook with client-side cookie setting
"use client";

import { useMutation } from "@tanstack/react-query";
import { useRouter } from "next/navigation";
import { toast } from "sonner";
import Cookies from "js-cookie";
import { ForgetPasswordFields } from "@/lib/schemas/auth.schema";
import { forgetPassword } from "../actions/forget-password.action";

export default function useForgetPassword() {
  const router = useRouter();

  const { isPending, error, mutate } = useMutation({
    mutationFn: async (data: ForgetPasswordFields) => {
      const result = await forgetPassword(data);

      if (result.error) {
        throw new Error(result.error);
      }

      return result.data;
    },
    onSuccess: (data) => {
      toast.success("تم إرسال رمز إعادة تعيين كلمة المرور بنجاح!");

      Cookies.set("forgetPasswordToken", data.token);

      if (data.type === "Email") {
        router.push("/auth/forget-password/reset-password/email");
      } else if (data.type === "WhatsApp") {
        router.push("/auth/forget-password/reset-password/otp");
      }
    },
    onError: (error) => {
      console.error("Forget password error:", error);
      toast.error(
        error?.message || "حدث خطأ أثناء إرسال رمز إعادة تعيين كلمة المرور"
      );
    },
  });

  return {
    isPending,
    error,
    forgetPassword: mutate,
  };
}
