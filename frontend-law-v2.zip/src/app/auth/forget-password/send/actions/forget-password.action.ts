"use server";

import { ForgetPasswordFields } from "@/lib/schemas/auth.schema";

export async function forgetPassword(data: ForgetPasswordFields) {
  try {
    const response = await fetch(`${process.env.API}/Forget-Password`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(data),
    });

    const result = await response.json();

    if (!response.ok) {
      return {
        error: result.message || `HTTP error! status: ${response.status}`,
      };
    }

    return { success: true, data: { ...result, type: data.type } };
  } catch (error) {
    return {
      error:
        error instanceof Error
          ? error.message
          : "An unexpected error occurred while processing forget password request",
    };
  }
}
