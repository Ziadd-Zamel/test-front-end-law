"use client";

import { useMutation } from "@tanstack/react-query";
import { useRouter } from "next/navigation";
import { toast } from "sonner";
import { verifyForgerCode } from "../actions/reset-password.action";

export default function useVerifyCode() {
  const router = useRouter();

  const { isPending, error, mutate } = useMutation({
    mutationFn: async (code: string) => {
      const result = await verifyForgerCode(code);

      if (result.error) {
        throw new Error(result.error);
      }

      return result.data;
    },
    onSuccess: () => {
      toast.success("تم التحقق من رقم واتساب بنجاح ");
      router.push("/auth/forget-password/reset-password/whatsapp");
    },
    onError: (error) => {
      console.error("Verify WhatsApp error:", error);
      toast.error(error?.message || "حدث خطأ أثناء التحقق من رمز واتساب ");
    },
  });

  return { isPending, error, verify: mutate };
}
