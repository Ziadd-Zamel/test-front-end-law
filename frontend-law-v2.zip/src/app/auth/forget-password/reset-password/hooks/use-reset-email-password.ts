"use client";

import { useMutation } from "@tanstack/react-query";
import { useRouter } from "next/navigation";
import { toast } from "sonner";
import { ResetEmailPasswordFields } from "@/lib/schemas/auth.schema";
import { resetEmailPassword } from "../actions/reset-password.action";

export default function useResetEmailPassword() {
  const router = useRouter();

  const { isPending, error, mutate } = useMutation({
    mutationFn: async (data: ResetEmailPasswordFields) => {
      const result = await resetEmailPassword(data);

      if (result.error) {
        throw new Error(result.error);
      }

      return result.data;
    },
    onSuccess: () => {
      toast.success(
        "تم إعادة تعيين كلمة المرور بنجاح! يمكنك الآن تسجيل الدخول."
      );
      router.push("/auth/login");
    },
    onError: (error) => {
      console.error("Reset email password error:", error);
      toast.error(error?.message || "حدث خطأ أثناء إعادة تعيين كلمة المرور");
    },
  });

  return {
    isPending,
    error,
    resetEmailPassword: mutate,
  };
}
