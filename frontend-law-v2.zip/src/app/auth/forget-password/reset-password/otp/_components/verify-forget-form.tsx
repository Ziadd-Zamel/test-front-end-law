"use client";

import OTPForm from "@/app/auth/_components/otp-form";
import useVerifyCode from "../../hooks/use-verify-forget";

export default function VerifyForgetForm() {
  const { verify, isPending: isVerifyPending } = useVerifyCode();

  return <OTPForm onVerify={verify} isVerifyPending={isVerifyPending} />;
}
