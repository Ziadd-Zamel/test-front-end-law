"use server";

import {
  ResetEmailPasswordFields,
  ResetWhatsPasswordFields,
} from "@/lib/schemas/auth.schema";
import { cookies } from "next/headers";
import { headers } from "next/headers";

export async function resetEmailPassword(data: ResetEmailPasswordFields) {
  try {
    const headersList = await headers();
    const referer = headersList.get("referer");

    if (!referer) {
      return { error: "Unable to get URL parameters" };
    }

    const url = new URL(referer);
    const token = url.searchParams.get("token");
    const email = url.searchParams.get("email");

    if (!token) {
      return { error: "Token not found in URL" };
    }

    if (!email) {
      return { error: "Email not found in URL" };
    }

    // Extract password fields from form data
    const { password, confirmPassword } = data;

    // Prepare the request body with all required fields
    const requestBody = {
      password,
      confirmPassword,
      token,
      email,
    };

    const response = await fetch(`${process.env.API}/Reset-Email-Password`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify(requestBody),
    });

    const result = await response.json();

    if (!response.ok) {
      return {
        error: result.message || `HTTP error! status: ${response.status}`,
      };
    }

    return { success: true, data: result };
  } catch (error) {
    return {
      error:
        error instanceof Error
          ? error.message
          : "An unexpected error occurred while resetting email password",
    };
  }
}
export async function resetWhatsPassword(data: ResetWhatsPasswordFields) {
  try {
    const cookieStore = await cookies();
    const token = cookieStore.get("forgetPasswordToken")?.value;

    if (!token) {
      return { error: "Token not found in cookies" };
    }

    const response = await fetch(`${process.env.API}/Reset-Whats-Password`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify(data),
    });

    const result = await response.json();

    if (!response.ok) {
      return {
        error: result.message || `HTTP error! status: ${response.status}`,
      };
    }

    return { success: true, data: result };
  } catch (error) {
    return {
      error:
        error instanceof Error
          ? error.message
          : "An unexpected error occurred while resetting WhatsApp password",
    };
  }
}

export async function verifyForgerCode(code: string) {
  try {
    const cookieStore = await cookies();
    const token = cookieStore.get("forgetPasswordToken")?.value;

    if (!token) {
      return { error: "Token not found in cookies" };
    }

    const response = await fetch(`${process.env.API}/Verify/Code`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify({
        code: code,
        typeOfGenerate: "ForgetPassword",
      }),
    });

    const result = await response.json();

    if (!response.ok) {
      return {
        error: result.message || `HTTP error! status: ${response.status}`,
      };
    }

    return { success: true, data: result };
  } catch (error) {
    return {
      error:
        error instanceof Error
          ? error.message
          : "An unexpected error occurred while verifying WhatsApp code",
    };
  }
}
