"use client";

import OTPForm from "../../_components/otp-form";
import { useVerificationLogin } from "../_hooks/use-verification-login";

export default function VerifyCodeForm() {
  const { loginWithCode, isPending: isVerifyPending } = useVerificationLogin();

  const handleVerify = (code: string) => {
    loginWithCode({ code });
  };

  return (
    <OTPForm
      onVerify={handleVerify}
      isVerifyPending={isVerifyPending}
      title="رمز التحقق"
      description="أدخل رمز التحقق المرسل إليك (6 أرقام)"
      submitButtonText="تسجيل الدخول"
      submitButtonLoadingText="جاري التحقق..."
    />
  );
}
