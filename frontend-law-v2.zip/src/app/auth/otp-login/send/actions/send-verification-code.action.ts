import { SendVerificationCodeFields } from "@/lib/schemas/auth.schema";

export async function sendVerificationCode(data: SendVerificationCodeFields) {
  try {
    const url = `${
      process.env.NEXT_PUBLIC_API
    }/Login-OTP?Identity=${encodeURIComponent(data.identity)}`;

    const response = await fetch(url, {
      method: "POST",
      headers: {
        accept: "*/*",
      },
    });

    const result = await response.json();
    console.log("Response:", response.status, result);

    if (!response.ok) {
      return {
        error:
          result.message ||
          result.title ||
          `HTTP error! status: ${response.status}`,
      };
    }

    return {
      success: true,
      data: {
        message: result.message,
        token: result.token,
        phone: result.phone,
        typeUser: result.typeUser,
        gender: result.gender,
      },
    };
  } catch (error) {
    console.error("Send verification code error:", error);
    return {
      error:
        error instanceof Error
          ? error.message
          : "An unexpected error occurred while sending verification code",
    };
  }
}
