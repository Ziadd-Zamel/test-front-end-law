"use client";

import { useMutation } from "@tanstack/react-query";
import { useRouter } from "next/navigation";
import { toast } from "sonner";
import Cookies from "js-cookie";
import { SendVerificationCodeFields } from "@/lib/schemas/auth.schema";
import { sendVerificationCode } from "../actions/send-verification-code.action";

export default function useSendVerificationCode() {
  const router = useRouter();

  const { isPending, error, mutate } = useMutation({
    mutationFn: async (data: SendVerificationCodeFields) => {
      const result = await sendVerificationCode(data);

      if (result.error) {
        throw new Error(result.error);
      }

      return result.data;
    },
    onSuccess: (data) => {
      toast.success(data?.message || "تم إرسال رمز التحقق بنجاح!");

      Cookies.set("verificationToken", data?.token);

      router.push("/auth/otp-login/otp");
    },
    onError: (error) => {
      console.error("Send verification code error:", error);
      toast.error(error?.message || "حدث خطأ أثناء إرسال رمز التحقق");
    },
  });

  return {
    isPending,
    error,
    sendVerificationCode: mutate,
  };
}
